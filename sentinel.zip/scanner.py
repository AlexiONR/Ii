"""
محرك الفحص - Sentinel Scanner
يفحص رابطاً معطى من حيث:
  1. الاتصال الأساسي (status code, redirects, response time)
  2. شهادة SSL/TLS (الصلاحية، تاريخ الانتهاء، المُصدر)
  3. رؤوس الأمان (Security Headers): HSTS, CSP, X-Frame-Options, إلخ
  4. معلومات عامة عن النطاق (IP، استخدام HTTPS)

كل الفحوصات هنا "passive" أي تعتمد على طلبات HTTP/TLS عادية لا تختلف
عن طلب متصفح طبيعي، ولا تتضمن أي محاولة استغلال أو هجوم فعلي.
"""
import socket
import ssl
import time
import datetime
from urllib.parse import urlparse

import requests

REQUEST_TIMEOUT = 8
USER_AGENT = "Sentinel-Scanner/1.0 (+security-headers-check)"

# الرؤوس الأمنية المهمة وما الذي تحققه كل واحدة
SECURITY_HEADERS = {
    "Strict-Transport-Security": {
        "label": "HSTS",
        "desc": "يفرض الاتصال عبر HTTPS فقط ويمنع التراجع إلى HTTP",
        "weight": 15,
    },
    "Content-Security-Policy": {
        "label": "CSP",
        "desc": "يقيّد مصادر تحميل المحتوى ويقلل من هجمات XSS",
        "weight": 20,
    },
    "X-Frame-Options": {
        "label": "X-Frame-Options",
        "desc": "يمنع تضمين الصفحة داخل iframe (Clickjacking)",
        "weight": 10,
    },
    "X-Content-Type-Options": {
        "label": "X-Content-Type-Options",
        "desc": "يمنع المتصفح من تخمين نوع المحتوى (MIME sniffing)",
        "weight": 10,
    },
    "Referrer-Policy": {
        "label": "Referrer-Policy",
        "desc": "يتحكم بالمعلومات المرسلة في رأس Referer بين الصفحات",
        "weight": 7,
    },
    "Permissions-Policy": {
        "label": "Permissions-Policy",
        "desc": "يتحكم بصلاحيات المتصفح (الكاميرا، الموقع، إلخ)",
        "weight": 8,
    },
}

MAX_HEADER_SCORE = sum(h["weight"] for h in SECURITY_HEADERS.values())


class ScanError(Exception):
    pass


def normalize_url(raw: str) -> str:
    raw = raw.strip()
    if not raw:
        raise ScanError("الرابط فاضي")
    if not raw.startswith(("http://", "https://")):
        raw = "https://" + raw
    parsed = urlparse(raw)
    if not parsed.netloc:
        raise ScanError("صيغة الرابط غير صحيحة")
    return raw


def check_connection(url: str):
    """يحاول الاتصال بالرابط ويرجع معلومات الاستجابة الأساسية."""
    start = time.time()
    try:
        resp = requests.get(
            url,
            timeout=REQUEST_TIMEOUT,
            headers={"User-Agent": USER_AGENT},
            allow_redirects=True,
        )
    except requests.exceptions.SSLError as e:
        raise ScanError(f"خطأ في شهادة SSL: تعذّر إنشاء اتصال آمن")
    except requests.exceptions.ConnectionError:
        raise ScanError("تعذّر الاتصال بالرابط - تأكد أن الموقع متاح")
    except requests.exceptions.Timeout:
        raise ScanError("انتهت مهلة الاتصال - الموقع لا يستجيب")
    except requests.exceptions.RequestException as e:
        raise ScanError(f"فشل الاتصال: {str(e)[:120]}")

    elapsed_ms = round((time.time() - start) * 1000)
    redirect_chain = [r.url for r in resp.history] + [resp.url]

    return {
        "status_code": resp.status_code,
        "final_url": resp.url,
        "response_time_ms": elapsed_ms,
        "redirect_count": len(resp.history),
        "redirect_chain": redirect_chain if len(redirect_chain) > 1 else [],
        "headers": dict(resp.headers),
        "uses_https": resp.url.startswith("https://"),
    }


def check_ssl_certificate(hostname: str, port: int = 443):
    """يفحص شهادة SSL مباشرة عبر socket (بدون مكتبات خارجية)."""
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=REQUEST_TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
    except (socket.gaierror, socket.timeout):
        return {"valid": False, "error": "تعذّر الوصول إلى المنفذ 443 (HTTPS)"}
    except ssl.SSLCertVerificationError as e:
        return {"valid": False, "error": "الشهادة غير موثوقة أو منتهية"}
    except Exception as e:
        return {"valid": False, "error": f"تعذّر فحص الشهادة: {str(e)[:100]}"}

    not_after = cert.get("notAfter")
    not_before = cert.get("notBefore")
    expiry_date = None
    days_remaining = None
    if not_after:
        try:
            expiry_date = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_remaining = (expiry_date - datetime.datetime.utcnow()).days
        except ValueError:
            pass

    issuer = dict(x[0] for x in cert.get("issuer", []))
    subject = dict(x[0] for x in cert.get("subject", []))

    return {
        "valid": True,
        "issuer": issuer.get("organizationName", issuer.get("commonName", "غير معروف")),
        "subject": subject.get("commonName", hostname),
        "issued_on": not_before,
        "expires_on": not_after,
        "days_remaining": days_remaining,
        "expiring_soon": days_remaining is not None and days_remaining < 21,
        "expired": days_remaining is not None and days_remaining < 0,
        "protocol": cipher[1] if cipher else "غير معروف",
        "cipher": cipher[0] if cipher else "غير معروف",
    }


def resolve_ip(hostname: str):
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror:
        return None


def analyze_security_headers(headers: dict):
    """يحلل الرؤوس الأمنية الموجودة والمفقودة في استجابة HTTP."""
    headers_lower = {k.lower(): v for k, v in headers.items()}
    present = {}
    missing = {}
    score = 0

    for header_name, meta in SECURITY_HEADERS.items():
        key = header_name.lower()
        if key in headers_lower:
            present[header_name] = {"value": headers_lower[key], **meta}
            score += meta["weight"]
        else:
            missing[header_name] = meta

    return {
        "present": present,
        "missing": missing,
        "score": score,
        "max_score": MAX_HEADER_SCORE,
        "percentage": round((score / MAX_HEADER_SCORE) * 100) if MAX_HEADER_SCORE else 0,
    }


def compute_risk(connection: dict, ssl_info: dict, headers_analysis: dict):
    """يحسب درجة خطورة إجمالية (0 = آمن جداً، 100 = خطير جداً) وتصنيفها."""
    score = 0  # درجة الخطر التراكمية
    reasons = []

    if not connection.get("uses_https"):
        score += 35
        reasons.append("الموقع لا يستخدم HTTPS - الاتصال غير مشفّر")

    if not ssl_info.get("valid", False) and connection.get("uses_https"):
        score += 30
        reasons.append(ssl_info.get("error", "شهادة SSL غير صالحة"))
    elif ssl_info.get("valid"):
        if ssl_info.get("expired"):
            score += 30
            reasons.append("شهادة SSL منتهية الصلاحية")
        elif ssl_info.get("expiring_soon"):
            score += 8
            reasons.append("شهادة SSL ستنتهي قريباً (أقل من 21 يوم)")

    header_pct = headers_analysis.get("percentage", 0)
    header_risk = round((100 - header_pct) * 0.35)
    score += header_risk
    if header_pct < 40:
        reasons.append("معظم رؤوس الأمان المهمة غير مُفعّلة")

    status = connection.get("status_code", 0)
    if status >= 500:
        score += 10
        reasons.append(f"الخادم يرجع خطأ ({status})")

    score = max(0, min(100, score))

    if score < 25:
        level = "safe"
    elif score < 55:
        level = "warning"
    else:
        level = "danger"

    if not reasons:
        reasons.append("لم تُكتشف مشاكل واضحة في الفحوصات الأساسية")

    return {"score": score, "level": level, "reasons": reasons}


def run_full_scan(raw_url: str) -> dict:
    """ينسّق عملية الفحص الكاملة ويرجع تقريراً موحّداً."""
    url = normalize_url(raw_url)
    parsed = urlparse(url)
    hostname = parsed.hostname

    connection = check_connection(url)

    final_parsed = urlparse(connection["final_url"])
    final_hostname = final_parsed.hostname or hostname

    ip_address = resolve_ip(final_hostname)

    if connection["uses_https"]:
        ssl_info = check_ssl_certificate(final_hostname)
    else:
        ssl_info = {"valid": False, "error": "الموقع لا يستخدم بروتوكول HTTPS"}

    headers_analysis = analyze_security_headers(connection["headers"])
    risk = compute_risk(connection, ssl_info, headers_analysis)

    return {
        "input_url": raw_url,
        "scanned_url": url,
        "hostname": final_hostname,
        "ip_address": ip_address,
        "connection": connection,
        "ssl": ssl_info,
        "headers_analysis": headers_analysis,
        "risk": risk,
        "scanned_at": datetime.datetime.utcnow().isoformat() + "Z",
    }
