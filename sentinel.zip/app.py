"""
Sentinel - موقع فحص الروابط الأمني
Flask app رئيسي: المصادقة، الجلسات، والمسارات (routes)
"""
import json
import os
import re
import secrets
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash

import database as db
from scanner import run_full_scan, ScanError

app = Flask(__name__)
# يقرأ المفتاح من متغير بيئة SECRET_KEY إن وُجد (للنشر)، وإلا يستخدم قيمة افتراضية للتشغيل المحلي فقط
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me-5ea29abd6dc6a01a5a7e30b15c257ff6")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_user():
    user = None
    if "user_id" in session:
        user = {"id": session["user_id"], "username": session.get("username")}
    return {"current_user": user}


# ---------------------------------------------------------------------------
# الصفحات العامة
# ---------------------------------------------------------------------------

@app.route("/")
def home():
    return render_template("home.html")


# ---------------------------------------------------------------------------
# المصادقة
# ---------------------------------------------------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")

        error = None
        if not USERNAME_RE.match(username):
            error = "اسم المستخدم يجب أن يكون 3-20 حرف، أحرف إنجليزية وأرقام و _ فقط"
        elif len(password) < 8:
            error = "كلمة السر يجب أن تكون 8 أحرف على الأقل"
        elif password != confirm:
            error = "كلمتا السر غير متطابقتين"
        elif db.get_user_by_username(username):
            error = "اسم المستخدم مستخدم مسبقاً"

        if error:
            return render_template("register.html", error=error, username=username)

        password_hash = generate_password_hash(password)
        user_id = db.create_user(username, password_hash)
        session.clear()
        session["user_id"] = user_id
        session["username"] = username
        return redirect(url_for("dashboard"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = db.get_user_by_username(username)
        # رسالة خطأ عامة وموحّدة لمنع تسريب معلومة "هل المستخدم موجود؟"
        if not user or not check_password_hash(user["password_hash"], password):
            return render_template("login.html", error="اسم المستخدم أو كلمة السر غير صحيحة", username=username)

        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        next_url = request.args.get("next")
        return redirect(next_url or url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# ---------------------------------------------------------------------------
# لوحة التحكم والفحص
# ---------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    scans = db.get_scans_for_user(session["user_id"], limit=50)
    for s in scans:
        s["summary"] = json.loads(s["summary_json"])
    return render_template("dashboard.html", scans=scans)


@app.route("/scan", methods=["POST"])
@login_required
def scan():
    raw_url = request.form.get("url", "") if not request.is_json else (request.get_json() or {}).get("url", "")

    try:
        report = run_full_scan(raw_url)
    except ScanError as e:
        payload = {"ok": False, "error": str(e)}
        if request.is_json:
            return jsonify(payload), 400
        flash(str(e), "error")
        return redirect(url_for("dashboard"))
    except Exception:
        payload = {"ok": False, "error": "حدث خطأ غير متوقع أثناء الفحص"}
        if request.is_json:
            return jsonify(payload), 500
        flash(payload["error"], "error")
        return redirect(url_for("dashboard"))

    scan_id = db.save_scan(
        user_id=session["user_id"],
        target_url=report["scanned_url"],
        risk_level=report["risk"]["level"],
        risk_score=report["risk"]["score"],
        summary_json=json.dumps(report, ensure_ascii=False),
    )
    report["id"] = scan_id

    if request.is_json:
        return jsonify({"ok": True, "report": report})

    return redirect(url_for("scan_detail", scan_id=scan_id))


@app.route("/scan/<int:scan_id>")
@login_required
def scan_detail(scan_id):
    record = db.get_scan_by_id(scan_id, session["user_id"])
    if not record:
        flash("الفحص غير موجود", "error")
        return redirect(url_for("dashboard"))
    record["summary"] = json.loads(record["summary_json"])
    return render_template("scan_detail.html", scan=record)


@app.route("/scan/<int:scan_id>/delete", methods=["POST"])
@login_required
def delete_scan(scan_id):
    db.delete_scan(scan_id, session["user_id"])
    return redirect(url_for("dashboard"))


# ---------------------------------------------------------------------------
# تشغيل التطبيق
# ---------------------------------------------------------------------------

db.init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug_mode = os.environ.get("FLASK_DEBUG", "1") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug_mode)
