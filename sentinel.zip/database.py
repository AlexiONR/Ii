"""
وحدة قاعدة البيانات لمشروع Sentinel
تستخدم sqlite3 مباشرة (بدون ORM) لتبسيط الاعتمادات.
"""
import sqlite3
import os
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sentinel.db")


@contextmanager
def get_db():
    """يفتح اتصال بقاعدة البيانات ويغلقه تلقائياً بعد الانتهاء."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """ينشئ الجداول إذا لم تكن موجودة. تُستدعى مرة واحدة عند تشغيل التطبيق."""
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                username      TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at    TEXT NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS scans (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL,
                target_url    TEXT NOT NULL,
                risk_level    TEXT NOT NULL,        -- safe | warning | danger
                risk_score    INTEGER NOT NULL,     -- 0-100
                summary_json  TEXT NOT NULL,        -- نتائج الفحص كاملة (JSON)
                created_at    TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_scans_user ON scans(user_id, created_at DESC);
            """
        )


# ---------- عمليات المستخدمين ----------

def create_user(username: str, password_hash: str) -> int:
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, password_hash),
        )
        return cur.lastrowid


def get_user_by_username(username: str):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        return dict(row) if row else None


def get_user_by_id(user_id: int):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        return dict(row) if row else None


# ---------- عمليات الفحوصات ----------

def save_scan(user_id: int, target_url: str, risk_level: str, risk_score: int, summary_json: str) -> int:
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO scans (user_id, target_url, risk_level, risk_score, summary_json)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, target_url, risk_level, risk_score, summary_json),
        )
        return cur.lastrowid


def get_scans_for_user(user_id: int, limit: int = 50):
    with get_db() as conn:
        rows = conn.execute(
            """SELECT * FROM scans WHERE user_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


def get_scan_by_id(scan_id: int, user_id: int):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM scans WHERE id = ? AND user_id = ?",
            (scan_id, user_id),
        ).fetchone()
        return dict(row) if row else None


def delete_scan(scan_id: int, user_id: int) -> bool:
    with get_db() as conn:
        cur = conn.execute(
            "DELETE FROM scans WHERE id = ? AND user_id = ?",
            (scan_id, user_id),
        )
        return cur.rowcount > 0
